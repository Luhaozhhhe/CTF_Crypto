<?php
system('echo "" > /var/www/action.log');
system('rm -rf /var/www/banned/*');
?>