<?php
require 'config.php';

$post_id = $_GET['id'] ?? 0;

try {
    $stmt = $pdo->prepare("SELECT posts.id, posts.title, posts.content, posts.created_at, users.username 
                           FROM posts 
                           JOIN users ON posts.user_id = users.id 
                           WHERE posts.id = ?");
    $stmt->execute([$post_id]);
    $post = $stmt->fetch();

    if (!$post) {
        die("Post not found");
    }

    $stmt = $pdo->prepare("SELECT replies.id, replies.content, replies.created_at, users.username 
                           FROM replies 
                           JOIN users ON replies.user_id = users.id 
                           WHERE replies.post_id = ? 
                           ORDER BY replies.created_at ASC");
    $stmt->execute([$post_id]);
    $replies = $stmt->fetchAll();
} catch(PDOException $e) {
    die("Error fetching post: " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html>
<head>
    <title><?= htmlspecialchars($post['title']) ?></title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        .post, .reply { border: 1px solid #ddd; padding: 15px; margin-bottom: 20px; border-radius: 5px; }
        .post h2, .reply h3 { margin-top: 0; }
        .meta { color: #666; font-size: 0.9em; margin-bottom: 10px; }
        .actions { margin-top: 20px; }
        .actions a { margin-right: 10px; }
    </style>
</head>
<body>
    <div class="post">
        <h2><?= htmlspecialchars($post['title']) ?></h2>
        <div class="meta">
            Posted by <?= htmlspecialchars($post['username']) ?> on <?= $post['created_at'] ?>
        </div>
        <p><?= nl2br(htmlspecialchars($post['content'])) ?></p>
    </div>

    <h3>Replies</h3>
    <?php if (empty($replies)): ?>
        <p>No replies yet. Be the first to reply!</p>
    <?php else: ?>
        <?php foreach ($replies as $reply): ?>
            <div class="reply">
                <div class="meta">
                    Replied by <?= htmlspecialchars($reply['username']) ?> on <?= $reply['created_at'] ?>
                </div>
                <p><?= nl2br(htmlspecialchars($reply['content'])) ?></p>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>

    <?php if (isset($_SESSION['user_id'])): ?>
        <div class="reply-form">
            <h3>Add a Reply</h3>
            <form method="post" action="reply.php">
                <input type="hidden" name="post_id" value="<?= $post['id'] ?>">
                <textarea name="content" placeholder="Your reply" required></textarea>
                <button type="submit">Submit Reply</button>
            </form>
        </div>
    <?php else: ?>
        <p><a href="login.php">Login</a> to reply to this post.</p>
    <?php endif; ?>

    <div class="actions">
        <a href="index.php">Back to Homepage</a>
    </div>
</body>
</html>