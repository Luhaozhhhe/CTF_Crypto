<?php
require 'config.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = $_POST['title'] ?? '';
    $content = $_POST['content'] ?? '';
    $username = $_SESSION['username'];

    if (has_sensitive_words($title) || has_sensitive_words($content)) {
        record_banned($username, $title . "|" . $content);
        die("Post contains sensitive words");
    }

    try {
        $stmt = $pdo->prepare("INSERT INTO posts (user_id, title, content) VALUES (?, ?, ?)");
        $stmt->execute([$_SESSION['user_id'], $title, $content]);

        log_action($username, 'create_post', 1);
        header("Location: index.php");
    } catch (PDOException $e) {
        log_action($username, 'create_post', 0, $e->getMessage());
        die("Post creation failed: " . $e->getMessage());
    }
}
?>
<!DOCTYPE html>
<form method="post">
    <input type="text" name="title" placeholder="Title" required>
    <textarea name="content" placeholder="Content" required></textarea>
    <button type="submit">Create Post</button>
</form>