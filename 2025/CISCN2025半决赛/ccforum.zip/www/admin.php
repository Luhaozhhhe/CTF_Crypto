<?php
require 'config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';

    try {
        $stmt = $pdo->prepare("SELECT * FROM admins WHERE username = ?");
        $stmt->execute([$username]);
        $admin = $stmt->fetch();

        if ($admin && password_verify($password, $admin['password'])) {
            $_SESSION['admin_id'] = $admin['id'];
            $_SESSION['admin_username'] = $admin['username'];
            $_SESSION['admin'] = true;
            log_action($username, 'admin_login', 1);
            header("Location: admin.php");
            exit();
        } else {
            log_action($username, 'admin_login', 0, 'Invalid credentials');
            die("Invalid credentials");
        }
    } catch (PDOException $e) {
        log_action($username, 'admin_login', 0, $e->getMessage());
        die("Admin login failed: " . $e->getMessage());
    }
}

if (!isset($_SESSION['admin']) || !$_SESSION['admin']) {
    die("Access denied. Please login as admin.");
}

$action_log_path = '/var/www/action.log';
if (!file_exists($action_log_path)) {
    die("Action log file not found.");
}

$action_log = file_get_contents($action_log_path);
$log_lines = explode("\n", $action_log);

$banned_users = [];
$failed_logs = [];

foreach ($log_lines as $line) {
    if (empty($line)) {
        continue;
    }

    $parts = explode(',', $line);
    if (count($parts) < 5) {
        continue;
    }

    $encoded_user = $parts[1];
    $action = $parts[2];
    $success = (int) $parts[3];
    $additional_info = $parts[4];

    if ($action === 'record_banned') {
        if ($success === 1) {
            $banned_users[$encoded_user][] = $additional_info;
        } else {
            $failed_logs[] = $additional_info;
        }
    }
}

$banned_contents = [];
foreach ($banned_users as $encoded_user => $logs) {
    $banned_dir = "/var/www/banned/{$encoded_user}";

    if (file_exists($banned_dir)) {
        $files = scandir($banned_dir);
        foreach ($files as $file) {
            if ($file !== '.' && $file !== '..') {
                $file_path = $banned_dir . '/' . $file;
                $content = file_get_contents($file_path);
                $banned_contents[$username][] = $content;
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 20px;
        }

        .container {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        h1 {
            color: #333;
        }

        .section {
            margin-bottom: 30px;
        }

        .section h2 {
            color: #555;
            border-bottom: 2px solid #ddd;
            padding-bottom: 10px;
        }

        .content {
            margin-top: 10px;
            padding: 10px;
            background-color: #f9f9f9;
            border-radius: 4px;
        }

        .content pre {
            white-space: pre-wrap;
            word-wrap: break-word;
        }
    </style>
</head>

<body>
    <div class="container">
        <h1>Admin Dashboard</h1>

        <div class="section">
            <h2>Banned Users and Contents</h2>
            <?php if (empty($banned_contents)): ?>
                <p>No banned content found.</p>
            <?php else: ?>
                <?php foreach ($banned_contents as $encoded_user => $contents): ?>
                    <div class="content">
                        <h3>User: <?php echo $encoded_user; ?></h3>
                        <?php foreach ($contents as $content): ?>
                            <pre><?php echo htmlspecialchars($content); ?></pre>
                        <?php endforeach; ?>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>

        <div class="section">
            <h2>Failed Logs</h2>
            <?php if (empty($failed_logs)): ?>
                <p>No failed logs found.</p>
            <?php else: ?>
                <div class="content">
                    <?php foreach ($failed_logs as $log): ?>
                        <p><?php echo htmlspecialchars($log); ?></p>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
</body>

</html>