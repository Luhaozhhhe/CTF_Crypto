<?php
require 'config.php';

// Fetch all posts from the database
try {
    $stmt = $pdo->query("SELECT posts.id, posts.title, posts.content, posts.created_at, users.username 
                         FROM posts 
                         JOIN users ON posts.user_id = users.id 
                         ORDER BY posts.created_at DESC");
    $posts = $stmt->fetchAll();
} catch (PDOException $e) {
    die("Error fetching posts: " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html>

<head>
    <title>CC Forum Homepage</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }

        .post {
            border: 1px solid #ddd;
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 5px;
        }

        .post h2 {
            margin-top: 0;
        }

        .post .meta {
            color: #666;
            font-size: 0.9em;
            margin-bottom: 10px;
        }

        .actions {
            margin-top: 20px;
        }

        .actions a {
            margin-right: 10px;
        }
    </style>
</head>

<body>
    <h1>Forum Homepage</h1>

    <div class="actions">
        <?php if (isset($_SESSION['user_id'])): ?>
            <a href="post.php">Create New Post</a>
            <a href="logout.php">Logout</a>
        <?php else: ?>
            <a href="login.php">Login</a>
            <a href="register.php">Register</a>
        <?php endif; ?>
    </div>
    <br/>

    <?php if (empty($posts)): ?>
        <p>No posts available. Be the first to create one!</p>
    <?php else: ?>
        <?php foreach ($posts as $post): ?>
            <div class="post">
                <h2><a href="view_post.php?id=<?= $post['id'] ?>"><?= htmlspecialchars($post['title']) ?></a></h2>
                <div class="meta">
                    Posted by <?= htmlspecialchars($post['username']) ?> on <?= $post['created_at'] ?>
                </div>
                <p><?= nl2br(htmlspecialchars($post['content'])) ?></p>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>
</body>

</html>