<?php
session_start();

define('DB_HOST', '127.0.0.1');
define('DB_PORT', '3306');
define('DB_NAME', 'forum');
define('DB_USER', 'mgr');
define('DB_PASS', 'j92wn0UXFYsUAFiN');

try {
    $pdo = new PDO(
        "mysql:host=" . DB_HOST . ";port=" . DB_PORT . ";dbname=" . DB_NAME,
        DB_USER,
        DB_PASS,
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

function encode_uname($username)
{
    return base64_encode($username);
}

function log_action($username, $action, $succ, $additional = '')
{
    $log_id = uniqid();
    $e_username = encode_uname($username);
    $log_line = sprintf(
        "%s,%s,%s,%d,%s\n",
        $log_id,
        $e_username,
        $action,
        $succ,
        $additional
    );

    file_put_contents('/var/www/action.log', $log_line, FILE_APPEND);
}

function record_banned($username, $banned)
{
    $e_username = encode_uname($username);
    $banned_dir = "/var/www/banned/{$e_username}";
    $created = true;
    if (!file_exists($banned_dir)) {
        $created = mkdir($banned_dir, 0750);
    }
    $log = "";
    $succ = 1;
    if (!$created) {
        $succ = 0;
        $log = "Failed to create record directory for " . $username;
    } else {
        $filename = $banned_dir . '/' . time() . '.txt';
        if (!file_put_contents($filename, $banned)) {
            $succ = 0;
            $log = "Failed to record banned content";
        }
    }
    log_action($username, 'record_banned', $succ, $log);
}

function has_sensitive_words($content)
{
    $SENSITIVE_WORDS = ['敏感词', 'SENSITIVE WORDS',];
    foreach ($SENSITIVE_WORDS as $word) {
        if (stripos($content, $word) !== false) {
            return true;
        }
    }
    return false;
}
?>