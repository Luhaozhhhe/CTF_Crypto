<?php
require 'config.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}


if ($_SERVER['REQUEST_METHOD'] === 'POST' && $_POST['post_id'] != null && $_POST['content'] != null) {
    $post_id = $_POST['post_id'] ?? 0;
    $content = $_POST['content'] ?? '';
    $username = $_SESSION['username'];

    if (has_sensitive_words($content)) {
        record_banned($username, $content);
        die("Reply contains sensitive words");
    }

    try {
        $stmt = $pdo->prepare("INSERT INTO replies (post_id, user_id, content) VALUES (?, ?, ?)");
        $stmt->execute([$post_id, $_SESSION['user_id'], $content]);

        log_action($username, 'create_reply', 1);
        header("Location: view_post.php?id=$post_id");
    } catch (PDOException $e) {
        log_action($username, 'create_reply', 0, $e->getMessage());
        die("Reply creation failed: " . $e->getMessage());
    }
}
?>