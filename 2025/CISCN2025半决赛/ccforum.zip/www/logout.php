<?php
require 'config.php';

if (isset($_SESSION['user_id'])) {
    log_action($_SESSION['username'], 'logout', 1);
    session_destroy();
}
header("Location: index.php");
exit;
?>