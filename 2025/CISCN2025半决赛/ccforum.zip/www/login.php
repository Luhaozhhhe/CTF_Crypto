<?php
require 'config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';

    try {
        $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ?");
        $stmt->execute([$username]);
        $user = $stmt->fetch();

        if ($user && password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            log_action($username, 'admin_login', 1);
            header("Location: index.php");
        } else {
            log_action($username, 'admin_login', 0, 'Invalid credentials');
            die("Invalid credentials");
        }
    } catch (PDOException $e) {
        log_action($username, 'admin_login', 0, $e->getMessage());
        die("Login failed: " . $e->getMessage());
    }
}
?>
<!DOCTYPE html>

<h1 style="color: #333; font-size: 16px; margin-bottom: 20px;">Welcome to the CC forum!</h1>
<div style="background-color: #f9f9f9; padding: 20px; border-radius: 8px; margin-bottom: 20px;"></div>
<p style="color: #333;">Please enter your username and password below to login.</p>
<form method="post">
    <input type="text" name="username" placeholder="Username" required>
    <br />
    <input type="password" name="password" placeholder="Password" required>
    <br />
    <button type="submit">Login</button>
</form>
</div>

<style>
    input {
        width: 240pt;
        padding: 8px;
        margin: 5px 0;
        border: 1px solid #ddd;
        border-radius: 4px;
    }

    button {
        background-color: #4CAF50;
        color: white;
        padding: 10px 20px;
        border: none;
        border-radius: 4px;
        cursor: pointer;
    }

    button:hover {
        background-color: #45a049;
    }

    h1,
    p {
        margin-bottom: 15px;
    }
</style>