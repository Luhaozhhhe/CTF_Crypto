<?php
require 'config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';

    if (strlen($username) <= 4 || strlen($password) < 12) {
        die("Username or password is too short. ");
    }

    if (strlen($username) >= 32 || strlen($password) >= 32) {
        die("Username or password is too long. ");
    }

    try {
        $stmt = $pdo->prepare("SELECT id FROM users WHERE username = ?");
        $stmt->execute([$username]);
        if ($stmt->fetch()) {
            log_action($username, 'register', 0, 'Username exists');
            die("Username already exists");
        }

        $hash = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $pdo->prepare("INSERT INTO users (username, password) VALUES (?, ?)");
        $stmt->execute([$username, $hash]);

        log_action($username, 'register', 1);
        header("Location: login.php");
    } catch (PDOException $e) {
        log_action($username, 'register', 0, $e->getMessage());
        die("Registration failed: " . $e->getMessage());
    }
}
?>

<!DOCTYPE html>


<h1 style="color: #333; font-size: 16px; margin-bottom: 20px;">Welcome to the CC forum!</h1>
<div style="background-color: #f9f9f9; padding: 20px; border-radius: 8px; margin-bottom: 20px;"></div>
<p style="color: #333;">Please enter your username and password below to register.</p>
<form method="post">
    <input type="text" name="username" placeholder="Username" required>
    <br />
    <input type="password" name="password" placeholder="Password" required>
    <br />
    <button type="submit">Register</button>
</form>
</div>

<style>
    input {
        width: 240pt;
        padding: 8px;
        margin: 5px 0;
        border: 1px solid #ddd;
        border-radius: 4px;
    }

    button {
        background-color: #4CAF50;
        color: white;
        padding: 10px 20px;
        border: none;
        border-radius: 4px;
        cursor: pointer;
    }

    button:hover {
        background-color: #45a049;
    }

    h1,
    p {
        margin-bottom: 15px;
    }
</style>