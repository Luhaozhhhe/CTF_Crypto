#!/bin/sh

chmod +x pwn
mv -f pwn /home/ctf/pwn