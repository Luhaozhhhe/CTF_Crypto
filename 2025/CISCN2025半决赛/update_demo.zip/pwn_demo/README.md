压缩文件命令：

```
tar -czvf update.tar.gz pwn update.sh
```

update.sh：pwn程序和题目绝对路径为：/home/ctf/pwn

上传update.tar.gz即可
