压缩文件命令：

```
tar -czvf update.tar.gz index.php update.sh
```

上传update.tar.gz即可
