#!/bin/bash

mv index.php /var/www/html/index.php